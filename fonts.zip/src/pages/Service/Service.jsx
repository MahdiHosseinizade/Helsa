import React from "react";
import Header from "../../components/Header/Header";
import SaveSection from "../../SectionPage/Service/SaveSection";
import Footer from "../../components/Footer/Footer";
import HostingSection from "../../SectionPage/Service/HostingSection";
import OurSuggestion from "../../SectionPage/Service/OurSuggestion";
import TextSummorazing from "../../SectionPage/Service/TextSummorazing";
export default function Service() {
   return (
      <>
         <Header />
         <TextSummorazing />
         <SaveSection />
         <HostingSection />
         <OurSuggestion />
         <Footer />
      </>
   );
}
