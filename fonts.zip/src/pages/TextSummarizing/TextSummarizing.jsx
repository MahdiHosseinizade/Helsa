
import { useRef, useState } from "react";
import BtnInfo from "../../components/common/btnInfo";
import BtnSuccess from "../../components/common/btnSuccess";
import Textarea from "../../components/common/textarea";
import Header from "../../components/Header/Header";

const TextSumm = () => {
  const textareaRef = useRef(null);
  const [summary, setSummary] = useState();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const value = textareaRef.current.value.trim();

    if (value === "") return alert("لطفا مقداری وارد کنید!");

    try {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/todos/1",
        {
          method: "POST",
          body: JSON.stringify({
            value,
          }),
        }
      );

      const data = response.json();
      setSummary(`لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
      استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله
      در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد
      نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
      کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان
      جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای
      طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان
      فارسی ایجاد کرد.`);
    } catch (ex) {
      console.log(ex);
      alert("خطا در ارسال");
    }
  };
  return (
    <section>
        <Header />
      <form className=" m-6" onSubmit={handleSubmit}>
        <div className="w-full flex flex-col flex-wrap md:flex-row">
          <Textarea ref={textareaRef} className="md:w-2/3" />
          <div className="md:w-1/3 text-right md:pr-10">
            <h3 className="font-bold">خلاصه متن:</h3>
            <p className="mb-4 mt-1 p-1 border min-h-32 rounded">{summary}</p>
          </div>
        </div>

        <div>
          <BtnSuccess Tag="button">ارسال</BtnSuccess>
          <BtnInfo Tag="button" type="reset">
            شروع مجدد
          </BtnInfo>
        </div>
      </form>
    </section>
  );
};

export default TextSumm;
