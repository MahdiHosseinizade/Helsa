import React from "react";
import Header from "../../components/Header/Header";
import LandingHome from "../../SectionPage/Home/LandingHome";
import Section1 from "../../SectionPage/Home/Section1";
import Main from "../../SectionPage/Home/Main";
import Footer from "../../components/Footer/Footer";
export default function Home() {
   return (
      <>
         <Header />
         <LandingHome />
         <Section1 />
         <Main />
         <Footer />
      </>
   );
}
