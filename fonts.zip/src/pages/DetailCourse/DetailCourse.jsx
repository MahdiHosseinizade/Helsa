import React from "react";
import Header from "../../components/Header/Header";
import Footer from "../../components/Footer/Footer";
import LeftContainer from "../../SectionPage/DetailCourse/LeftContainer";
import DescriptionCourse from "../../SectionPage/DetailCourse/DescriptionCourse";
import SectionCourse from "../../SectionPage/DetailCourse/SectionCourse";
export default function DetailCourse() {
   return (
      <div>
         <Header />
         <div className='center-container grid grid-cols-1 md:grid-cols-5 overflow-hidden'>
            {/* containet right  */}

            <div className='md:col-span-4 py-14'>
               <DescriptionCourse />
               <SectionCourse />
            </div>

            {/* container left  */}

            <div className='md:col-span-1 border-r border-gray-300 pr-5  py-14'>
               <LeftContainer />
            </div>
         </div>
         <Footer />
      </div>
   );
}
