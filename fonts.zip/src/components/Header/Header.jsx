import React, {useEffect, useRef, useState} from "react";
import {Link, useLocation} from "react-router-dom";
import {LiaSearchSolid} from "react-icons/lia";
import {LuMenu} from "react-icons/lu";
import {MenuCustomList} from "../Menu/Menu";

const ItemLink = [
   {title: "صفحه اصلی", path: "/"},
   {
      title: "دوره های آموزشی",
      path: "/courses",
      subMenu: [
         {title: "برنامه نویسی پایتون", path: "/courses/python"},
         {title: "یادگیری ماشین", path: "/courses/یادگیری ماشین"},
         {title: "یادگیری عمیق", path: "/courses/یادگیری عمیق"},
      ],
   },
   {title: "خدمات", path: "/service"},
   {title: "تماس با ما", path: "/contact"},
   {title: "درباره ما", path: "/about"},
];

export default function Header() {
   const [openDrawerMenu, setOpenDrawerMenu] = useState(false);
   const [headerSize, setHeaderSize] = useState(false);
   const [isResize, setIsResize] = useState(false);

   const containerMenu = useRef();

   const location = useLocation();

   const ShowDrawerMenu = () => {
      setOpenDrawerMenu(!openDrawerMenu);
   };

   useEffect(() => {
      window.scrollTo(0, 0);
   }, []);

   const resizeHeader = () => {
      window.addEventListener("scroll", () => {
         if (window.scrollY > 1) {
            setHeaderSize(true);
         } else {
            setHeaderSize(false);
         }
         if (window.screen.availWidth > 870) {
            setIsResize(true);
         } else {
            setIsResize(false);
         }
      });
      window.addEventListener("resize", () => {
         if (window.screen.availWidth > 870) {
            setIsResize(true);
         } else {
            setIsResize(false);
         }
      });
   };

   useEffect(() => {
      resizeHeader();
      return () => {
         resizeHeader();
      };
   }, []);
   return (
      <div className='md:sticky top-0 bg-white z-[555] relative shadow'>
         <div
            style={{transition: "0.3s"}}
            className={`container ${
               isResize && headerSize ? "md:p-2" : "px-7 lg:px-0 py-6 md:py-8"
            }   overflow-hidden items-center flex  justify-between max-w-screen-lg`}
         >
            {/* Logo */}
            <div>
               <Link to='/'>
                  <p className='font-bold text-xl'>HELSA</p>
               </Link>
            </div>
            <div className='flex items-center gap-7'>
               <div className='hidden md:flex gap-7 items-center'>
                  {ItemLink.map((link) =>
                     link.subMenu ? (
                        // MegaMenu Desktop

                        <MenuCustomList
                           key={link.title}
                           offset={isResize && headerSize ? 10 : 32}
                           className={`${location.pathname.includes(link.path) ? "text-pink" : "text-gray-600"}`}
                           handeler={
                              <Link to={link.path}>
                                 <span className='text-sm'>{link.title}</span>
                              </Link>
                           }
                        >
                           {link.subMenu.map((item) => (
                              <Link to={item.path} className='my-2.5 outline-none'>
                                 {item.title}
                              </Link>
                           ))}
                        </MenuCustomList>
                     ) : (
                        <Link key={link.title} to={link.path} className={`${location.pathname === link.path ? "text-pink" : "text-gray-600"}`}>
                           <span className='text-sm'>{link.title}</span>
                        </Link>
                     )
                  )}
               </div>

               {/* icon Search And Menu */}

               <div className='flex gap-4 items-center'>
                  <span className='text-2xl md:text-xl text-gray-600'>
                     <LiaSearchSolid />
                  </span>
                  <span onClick={ShowDrawerMenu} className='md:hidden block text-2xl md:text-xl text-blue-600'>
                     <LuMenu />
                  </span>
               </div>
            </div>

            {/* Container DrawerMenu Mobile */}

            <div
               ref={containerMenu}
               className='absolute subMenuHeader md:hidden w-full h-full bg-transparent top-[55px]   left-1/2 -translate-x-1/2   overflow-hidden'
               style={{height: openDrawerMenu ? `${containerMenu.current.scrollHeight}px` : "0px", transition: "0.5s"}}
            >
               <div className='p-5 h-full '>
                  <div className='bg-white  border-t-[3px] border-blue-600 '>
                     {ItemLink.map((link) => (
                        <Link key={link.title} to={link.path} className={`${location.pathname === link.path ? "text-pink" : "text-gray-600"}`}>
                           <p className='text-sm p-3'>{link.title}</p>
                        </Link>
                     ))}
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
}
