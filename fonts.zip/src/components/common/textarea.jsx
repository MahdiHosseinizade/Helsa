import { forwardRef } from "react";

const Textarea = forwardRef(function Textarea({ className, ...rest }, ref) {
  return (
    <textarea
      ref={ref}
      className={"text-sm w-full p-3 shadow-sm mb-40 " + className}
      placeholder="متن خود را در این قسمت وارد کنید..."
      rows="10"
      {...rest}
    ></textarea>
  );
});

export default Textarea;
