import React from "react";
import {MdOutlineRssFeed} from "react-icons/md";
import {FaInstagram} from "react-icons/fa";
import {FaXTwitter} from "react-icons/fa6";
import {FaFacebookF} from "react-icons/fa";

export default function Footer() {
   return (
      <div className='bg-blueGray text-white'>
         <div className='grid md:grid-cols-4 grid-cols-1 center-container py-20'>
            <div className='flex md:col-span-2  gap-20 justify-center md:justify-start'>
               <div className=''>
                  <p className='my-4'>تماس با ما</p>
                  <p className='my-4'>info@diviai.com</p>
                  <p className='my-4'>info@diviai.com</p>
                  <p className='my-4'>info@diviai.com</p>
               </div>
               <div className=''>
                  <p className='my-4'>شرکت ما</p>
                  <p className='my-4'>info@diviai.com</p>
                  <p className='my-4'>info@diviai.com</p>
                  <p className='my-4'>info@diviai.com</p>
               </div>
            </div>
            <div className='col-span-2'>
               <img src='http://farascience.ir/wp-content/uploads/2024/06/logo_05-dark.png' alt='' />
               <p className=' text-gray-500 p-5'>
                  لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
                  سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
               </p>
            </div>
         </div>
         <div className='bg-[#222222] p-10 md:p-20 '>
            <div className='gap-5 flex justify-end  center-container'>
               <span className='text-[#2EA3F2] text-2xl '>دسته ها </span>
               <span className='text-[#2EA3F2] text-2xl '>بایگانی ها</span>
            </div>
         </div>
         <div className='bg-[#191919] p-3 '>
            <div className='gap-5 md:flex justify-between  center-container items-center text-gray-600'>
               <div className=' text-sm'>طراحی شده توسط Elegant Themes | ترجمه و بهینه سازی توسط WordPress</div>
               <div className='flex justify-end mt-3 md:mt-0 gap-5 items-center'>
                  <div className='text-2xl'>
                     <FaFacebookF />
                  </div>
                  <div className='text-3xl'>
                     <FaXTwitter />
                  </div>
                  <div className='text-3xl'>
                     <FaInstagram />
                  </div>
                  <div className='text-4xl'>
                     <MdOutlineRssFeed />
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
}
