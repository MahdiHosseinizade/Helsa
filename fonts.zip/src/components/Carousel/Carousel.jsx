import React, {useRef, useState} from "react";
// Import Swiper React components
import {Swiper, SwiperSlide} from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
// import required modules
import {Pagination, Navigation, Autoplay} from "swiper/modules";

export default function App({children, spaceBetween}) {
   return (
      <>
         <Swiper
            slidesPerView={1}
            spaceBetween={spaceBetween}
            grabCursor
            loop
            navigation={{
               nextEl: ".next",
               prevEl: ".prev",
            }}
            autoplay={{
               delay: 2500,
               disableOnInteraction: false,
            }}
            breakpoints={{
               640: {
                  slidesPerView: 2,
               },
               768: {
                  slidesPerView: 3,
               },
               1024: {
                  slidesPerView: 4,
               },
            }}
            modules={[Pagination, Navigation, Autoplay]}
            className='swiper'
         >
            {children}
         </Swiper>
      </>
   );
}
