import Home from "./pages/Home/Home";
import Courses from "./pages/AllCourses/Courses";
import Service from "./pages/Service/Service";
import DetailCourse from "./pages/DetailCourse/DetailCourse";
import TextSumm from "./pages/TextSummarizing/TextSummarizing";
let routes = [
   {path: "/", element: <Home />},
   {path: "/courses", element: <Courses />},
   {path: "/service", element: <Service />},
   {path: "/courses/:courseName", element: <DetailCourse />},
   {path: "/service/summorize", element: <TextSumm />}
   // {path: "/contact", element: <Contact />},
   // {path: "/about-me", element: <AboutUs />},
];
export {routes};
