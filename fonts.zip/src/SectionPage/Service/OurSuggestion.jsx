import React from "react";
import BoxItem from "../../components/BoxItem/BoxItem";

const arrBox = [
   {title: "منابع آزاد", image: "/img/icon (7).png"},
   {title: "سیستم پشتیبانی", image: "/img/icon (1).png"},
   {title: "مدیریت مشتری", image: "/img/icon (2).png"},
   {title: "مدیریت مالی", image: "/img/icon (5).png"},
   {title: "بدون برنامه نویسی", image: "/img/icon (3).png"},
   {title: "هوش مصنوعی", image: "/img/icon (6).png"},
];

export default function OurSuggestion() {
   return (
      <div className='bg-[#EDEDED] -mt-10 p-8 md:p-0'>
         <div className='pt-28 pb-16 center-container'>
            <p className='text-pink'>امکانات</p>
            <h2 className='text-2xl md:text-6xl font-bold  mt-5'>چیزی که ما پیشنهاد میدیم</h2>
            <div className='grid gap-8 grid-cols-1 md:grid-cols-3 mt-14'>
               {arrBox.map((item) => (
                  <BoxItem {...item} />
               ))}
            </div>
         </div>
      </div>
   );
}
