import React from "react";
import BoxTick from "../../components/BoxTick/BoxTick";
export default function SaveSection() {
   return (
      <div className='bg-blueGray pb-10 lg:pb-40'>
         <div className=' p-10 md:p-28  bg-cover' style={{backgroundImage: "url(/img/BackSaveSectionService.jpg)", backgroundPosition: "center bottom"}}>
            <div className='flex  items-center justify-center text-white text-center'>
               <div className=''>
                  <p className='mb-4 md:mb-8 text-pink'>هوش مصنوعی</p>
                  <h1 className='text-2xl md:text-7xl font-bold'>تشخیص تصویر</h1>
                  <p className='lg:w-1/2 lg:px-5 mx-auto mt-4 md:mt-6 text-sm md:text-lg text-gray-500 leading-8'>
                     لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
                     سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
                  </p>
                  <div className='w-max p-4 px-8 bg-pink  mx-auto mt-10 '>یک پروژه رو شروع کنید </div>
               </div>
            </div>
         </div>
         <div className='relative center-container text-white p-10 lg:p-0 mt-10'>
            <div className='lg:absolute left-0 lg:-translate-y-28 '>
               <img src='/img/service1.png' className='max-h-[800px]' alt='' />
            </div>
            <div className='lg:w-[59%] border border-pink -mt-5'>
               <div className='border-b border-pink p-3 text-pink'>ذخیره سازی</div>
               <div className='lg:pl-28 lg:pr-14 py-20 p-5'>
                  <h2 className='text-2xl md:text-7xl text-[#3C5BFF] font-bold'>خدمات ابری</h2>
                  <p className='my-5 mb-7 text-gray-400 leading-7'>
                     لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
                     سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
                  </p>
                  <BoxTick bg='bg-[#3C5BFF]' title='این یک عنصر سرگرم کننده است' />
                  <BoxTick bg='bg-[#3C5BFF]' title='در علامت تجاری بدون آرایش' />
                  <div className='w-max p-4 px-8 bg-pink   mt-10  font-bold'>مشاهده پلن ها</div>
               </div>
            </div>
         </div>
      </div>
   );
}
