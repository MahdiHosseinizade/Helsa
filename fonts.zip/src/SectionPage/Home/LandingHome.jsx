import React from "react";

export default function LandingHome() {
   return (
      <div className='text-white  bg-blueGray pb-20 lg:pb-0'>
         <div className='p-10   lg:px-0  lg:container py-7 md:py-20  md:grid grid-cols-7 flex-col-reverse flex gap-x-10  2xl:gap-x-14 '>
            <div className='md:col-span-3'>
               <img src='/img/homeHead.jpg' alt='' />
               <div className='p-5 text-xl mt-10 mx-auto bg-pink w-max'>خدمات هوش مصنوعی</div>
            </div>
            <div className='md:col-span-4 py-10'>
               <h2 className='text-[34px] font-bold mb-10 md:mb-20 '>هوش مصنوعی هلسا</h2>
               <p className=' text-gray-500 2xl:w-4/5 text-[13px] md:text-lg md:leading-8 leading-6'>
                  لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
                  سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
               </p>
            </div>
         </div>
      </div>
   );
}
