import React from "react";
import {HiOutlineCheck} from "react-icons/hi2";
import ImgBox from "../../components/ImgBox/ImgBox";
export default function Section1() {
   return (
      <ImgBox
         className='-mt-24 lg:left-0   lg:translate-x-[3px] lg:-translate-y-[100px] xl:lg:-translate-y-[180px]  '
         text='هوش مصنوعی'
         textBtn='مطالعه موردی'
         title='حدس و گمان را حذف می کنیم.'
      />
   );
}
