import React from "react";
import {RxLapTimer} from "react-icons/rx";
import {CiCircleMore} from "react-icons/ci";
import {FaUsers} from "react-icons/fa";
import {Link} from "react-router-dom";
export default function PopularCourses() {
   return (
      <div className='center-container mt-10'>
         <div className='text-2xl md:text-4xl mb-20 flex items-center gap-3'>
            <div className='size-6 bg-blue-gray-550 rounded'></div>
            <p>پر طرفدار ترین دوره ها</p>
         </div>
         <div className='mt-20 grid grid-cols-1 md:grid-cols-3 gap-10 p-5 md:p-0'>
            {/* Box Container Course */}

            {[7, 7, 7, 7, 7, 7].map((item, index) => (
               <Link key={index} to='/courses/python'>
                  <div className='rounded-xl overflow-hidden shadow-xl'>
                     <img
                        className='w-full'
                        src='https://imageio.forbes.com/specials-images/imageserve/64b5825a5b9b4d3225e9bd15/0x0.jpg?format=jpg&height=900&width=1600&fit=bounds'
                        alt=''
                     />
                     <div className='p-5 '>
                        <p>تدریس هوش مصنوعی در معماری</p>
                        <div className='flex gap-3 mt-2 border-b border-gray-300 pb-3'>
                           <div className='mt-2 flex items-center gap-2 text-gray-600'>
                              <span className='text-lg'>
                                 <RxLapTimer />
                              </span>
                              <span className=' text-sm mt-1'>20 ساعت آموزش</span>
                           </div>
                           <div className='mt-3 text-blue-700 cursor-pointer   flex items-center gap-2'>
                              <span className='text-xl'>
                                 <CiCircleMore />
                              </span>
                              <span className=' text-sm mt-1'>مشاهده جزئیات</span>
                           </div>
                        </div>
                        <div className='flex mt-3 justify-between items-center text-gray-600'>
                           <div className='flex items-center gap-1'>
                              <FaUsers className='text-xl' />
                              <p className='mt-1 text-sm'>521</p>
                           </div>
                           <p className='  text-left'>1,200,000 تومان</p>
                        </div>
                     </div>
                  </div>
               </Link>
            ))}
         </div>
      </div>
   );
}
