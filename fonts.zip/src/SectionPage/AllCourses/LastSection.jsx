import React from "react";

export default function LastSection() {
   return (
      <div className='p-5 md:p-0 '>
         <div className='center-container text-white p-8 lg:p-0 bg-blueGray my-5 md:my-32 shadow-md rounded-xl relative'>
            <div className='lg:w-[40%] lg:absolute top-1/4 left-20'>
               <p className='text-2xl md:text-3xl'>خود را به آینده راه اندازی کنید.</p>
               <p className='text-sm my-5 text-gray-500'>
                  لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
                  سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
               </p>
               <div className='px-7 py-4 mt-8 w-max bg-blue-gray-550 text-white mx-auto lg:mx-0'>اطلاعات بیشتر</div>
            </div>
            <img
               className='max-h-[450px]'
               src='https://layouts2.divi.support/virtual-courses/wp-content/uploads/sites/30/2023/09/virtual-courses-illustration-26@2x.png'
               alt=''
            />
         </div>
      </div>
   );
}
