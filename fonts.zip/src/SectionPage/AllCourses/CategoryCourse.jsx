import React from "react";
import {BiCategory} from "react-icons/bi";
import {PiPaintBrushBroad} from "react-icons/pi";
export default function CategoryCourse() {
   return (
      <div className=' mt-20  pb-20   relative bg-cover' style={{backgroundImage: "url('/img/6.png')"}}>
         <div className='center-container'>
            <div className='text-2xl md:text-4xl pb-3  mb-16 flex items-center gap-3 '>
               <BiCategory />
               <p>دسته بندی دوره ها</p>
            </div>
            <div className=' grid md:grid-cols-2 lg:grid-cols-4 gap-10  p-5 lg:p-0'>
               {[7, 8, 9, 9, 5, 5, 5, 5].map((item) => (
                  <div className=' cursor-pointer rounded-3xl p-10 text-center border border-gray-400/60 bg-white   transition-colors hover:bg-blue-gray-550 hover:text-white'>
                     <PiPaintBrushBroad className='text-5xl mx-auto' />
                     <p className='mt-5 text-2xl'>طراحی کردن</p>
                     <p className='mt-2 text-sm'>28 دوره</p>
                  </div>
               ))}
            </div>
         </div>
      </div>
   );
}
