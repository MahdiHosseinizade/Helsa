import {Button} from "@material-tailwind/react";
import React from "react";

const arrItem = [
   {title: "مدت زمان دوره ", text: "24 ساعت"},
   {title: "شهریه", text: " 1 میلیون و 200 هزار تومان"},
   {title: "زمان برگزاری", text: "دوشنبه و چهارشنبه ها 8 الی 12"},
   {title: "زمان شروع کلاس", text: ""},
];

export default function DescriptionCourse() {
   return (
      <div>
         <h1 className='text-3xl font-bold text-center md:text-right p-5 lg:p-0'>برنامه نویسی پایتون</h1>
         <div className='md:flex gap-28 mt-20'>
            <img className='max-h-44  mx-auto md:mx-0' src='/img/python.png' alt='' />
            <div className=' mx-auto w-max mt-8 md:mt-0 md:mx-0'>
               <h2 className='text-3xl text-blue-gray-750 font-bold'>دوره برنامه نویسی پایتون</h2>
               <p className='text-sm text-gray-500 my-2  mb-4'>(یک شرح کوتاه) مناسب برای متقاضیان یادگیری ……</p>
               {arrItem.map((item) => (
                  <p key={item.text} className='text-gray-500  my-3'>
                     <span className='text-gray-700'>{item.title} :</span>
                     <span className='text-sm'>{item.text}</span>
                  </p>
               ))}
            </div>
         </div>
         <div className='flex justify-end pe-10'>
            <Button className='text-sm font-thin text-white bg-pink '>ثبت نام</Button>
         </div>
      </div>
   );
}
