import React from "react";

export default function SectionCourse() {
   return (
      <div className='mt-40'>
         <h3 className='text-3xl text-blue-gray-750 '>سرفصل های دوره :</h3>

         <div className='mt-5'>
            {[7777, 1, 2, 2].map((item) => (
               <div className=''>
                  <p className='text-xl mb-2 mt-10 text-[#993366]'>آشنایی با برنامه نویسی پایتون</p>
                  {[8, 9, 9, 9].map((item) => (
                     <p className='my-2 text-sm text-gray-600'>مقایسه پایتون</p>
                  ))}
               </div>
            ))}
         </div>
      </div>
   );
}
