import React, {useEffect} from "react";
import {useRoutes} from "react-router-dom";
import {routes} from "./routes";
export default function App() {
   // useEffect(() => {
   //    document.onkeydown = function (e) {
   //       if (event.keyCode == 123) {
   //          return false;
   //       }
   //       if (e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)) {
   //          return false;
   //       }
   //       if (e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)) {
   //          return false;
   //       }
   //       if (e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)) {
   //          return false;
   //       }
   //       if (e.ctrlKey && e.keyCode == "U".charCodeAt(0)) {
   //          return false;
   //       }
   //    };
   // }, []);
   const router = useRoutes(routes);
   return <div dir='rtl'>{router}</div>;
}
