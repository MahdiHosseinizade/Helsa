const withMT = require("@material-tailwind/react/utils/withMT");

module.exports = withMT({
   content: ["./index.html", "./src/**/*.{vue,js,ts,jsx,tsx}"],
   theme: {
      screens: {
         sm: "640px",
         // => @media (min-width: 640px) { ... }

         md: "870px",
         // => @media (min-width: 768px) { ... }

         lg: "1080px",
         // => @media (min-width: 1024px) { ... }

         xl: "1240px",
         // => @media (min-width: 1024px) { ... }

         "2xl": "1440px",
         // => @media (min-width: 1024px) { ... }
      },
      container: {
         center: true,
      },
      extend: {
         colors: {
            blueGray: "#030929",
            "blue-gray-550": "#19184F",
            "blue-gray-750": "#000080",
            pink: "#DB0EB7",
            primary: "#286bb8",
         },
         borderWidth: {
            3: "3px",
         },
      },
   },
   plugins: [],
});
