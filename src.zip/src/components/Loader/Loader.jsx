import React from "react";
import "./Loader.css";
function Loader() {
   return <div className='loader absolute  inset-0 m-auto'></div>;
}

export default Loader;
